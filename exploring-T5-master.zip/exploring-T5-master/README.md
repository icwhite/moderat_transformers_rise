# exploring-T5
A repo to explore different NLP tasks which can be solved using T5
